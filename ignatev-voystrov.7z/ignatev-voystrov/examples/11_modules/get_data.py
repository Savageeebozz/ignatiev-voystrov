from pprint import pprint

from filter_functions import filter_file_lines

pprint(filter_file_lines('config_r1.txt', 'interface'))
