print('Import parse/cisco.py')


def parse_with_re(command):
    print('Parse command {} with regex'.format(command))


def parse_with_textfsm(command):
    print('Parse command {} with texfsm'.format(command))
