import time

for num in range(10):
    print(num)
    time.sleep(1)
