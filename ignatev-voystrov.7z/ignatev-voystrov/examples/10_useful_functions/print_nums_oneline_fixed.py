import time

for num in range(10):
    print(num, end=' ', flush=True)
    time.sleep(1)
