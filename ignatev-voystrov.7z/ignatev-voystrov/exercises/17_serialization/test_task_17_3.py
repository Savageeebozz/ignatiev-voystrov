import sys

import task_17_3

sys.path.append("..")

from pyneng_common_functions import check_function_exists, check_pytest


check_pytest(__loader__, __file__)


def test_function_created():
    """
    Проверка, что функция создана
    """
    check_function_exists(task_17_3, "parse_sh_cdp_neighbors")


def test_function_return_value():
    """
    Проверка работы функции
    """
    with open("sh_cdp_n_sw1.txt") as f:
        sh_cdp_n_sw1 = f.read()

    correct_return_value = {
        "SW1": {
            "Eth 0/1": {"R1": "Eth 0/0"},
            "Eth 0/2": {"R2": "Eth 0/0"},
            "Eth 0/3": {"R3": "Eth 0/0"},
            "Eth 0/4": {"R4": "Eth 0/0"},
        }
    }

    return_value = task_17_3.parse_sh_cdp_neighbors(sh_cdp_n_sw1)
    assert return_value != None, "Функция ничего не возвращает"
    assert (
        type(return_value) == dict
    ), f"По заданию функция должна возвращать словарь, а возвращает {type(return_value).__name__}"
    assert (
        correct_return_value == return_value
    ), "Функция возвращает неправильное значение"


def test_function_return_value_different_args():
    """
    Проверка работы функции на другом выводе
    """
    with open("sh_cdp_n_sw1.txt") as f:
        sh_cdp_n_sw1 = f.read()

    correct_return_value = {
        "SW1": {
            "Eth 0/1": {"R1": "Eth 0/0"},
            "Eth 0/2": {"R2": "Eth 0/0"},
            "Eth 0/3": {"R3": "Eth 0/0"},
            "Eth 0/4": {"R4": "Eth 0/0"},
        }
    }

    return_value = task_17_3.parse_sh_cdp_neighbors(sh_cdp_n_sw1)
    assert return_value != None, "Функция ничего не возвращает"
    assert type(return_value) == dict, (
        "По заданию функция должна возвращать словарь, а возвращает "
        f"{type(return_value).__name__}")
    assert correct_return_value == return_value, (
        "Функция возвращает неправильное значение"
    )
