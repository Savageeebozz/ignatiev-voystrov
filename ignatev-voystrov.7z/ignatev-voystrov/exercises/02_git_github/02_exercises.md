# Задания

### Задание 2.1

В этом задании необходимо:

* создать свой репозиторий для выполнения заданий на GitHub
* клонировать его на свою виртуалку/хост

Создать свой репозиторий на основе шаблона [репозиторий с заданиями и примерами](https://github.com/natenka/pyneng-examples-exercises).

> [Как создать репозиторий на основе шаблона](https://pyneng.readthedocs.io/ru/latest/book/02_git_github/git_github_changes.html).


